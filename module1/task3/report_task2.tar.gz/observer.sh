#!/bin/bash
 
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1
 
CONFIG_FILE="$SCRIPT_DIR/observer.conf"
LOG_FILE="$SCRIPT_DIR/observer.log"
LOCK_FILE="$SCRIPT_DIR/.observer.log.lock"
 
log_message() {
    {
        flock 200
        echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
    } 200>"$LOCK_FILE"
}
 
if [ ! -f "$CONFIG_FILE" ]; then
    log_message "Ошибка: файл конфигурации $CONFIG_FILE не найден"
    exit 1
fi
 
log_message "Проверка начата"
 
started=0
checked=0
 
while IFS= read -r script_name || [ -n "$script_name" ]; do
    [[ -z "$script_name" || "$script_name" =~ ^[[:space:]]*# ]] && continue

    script_name=$(echo "$script_name" | xargs)
    
    checked=$((checked + 1))

    if pgrep -f "$script_name" | grep -v $$ > /dev/null 2>&1; then
        log_message "✓ $script_name уже работает"
    else
        log_message "↻ Перезапуск $script_name"
        
        if [ -f "$SCRIPT_DIR/$script_name" ]; then
            chmod +x "$SCRIPT_DIR/$script_name"
            nohup "$SCRIPT_DIR/$script_name" >> "$SCRIPT_DIR/observer_exec.log" 2>&1 &
            TASK_PID=$!
            log_message "  Запущен с PID: $TASK_PID"
            started=$((started + 1))
        else
            log_message "✗ Ошибка: файл $script_name не найден в $SCRIPT_DIR"
        fi
    fi
done < "$CONFIG_FILE"
 
log_message "Проверка завершена (проверено: $checked, запущено: $started)"
#!/bin/bash
 
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1
 
SCRIPT_NAME=$(basename "$0")
TASK_ID="${SCRIPT_NAME%.*}-$$"
 
if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi
 
LOG_FILE="$SCRIPT_DIR/report_${TASK_ID}.log"
PIPE="/tmp/run/cuckoo.pid"
RESPONSE_PIPE="/tmp/run/response_$$.pid"
LOCK_FILE="$SCRIPT_DIR/.report_${TASK_ID}.log.lock"
 
log_message() {
    {
        flock 200
        echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $1" >> "$LOG_FILE"
    } 200>"$LOCK_FILE"
}
 
cleanup() {
    rm -f "$RESPONSE_PIPE"
}
 
trap cleanup EXIT
 
log_message "Скрипт запущен"

if [ ! -p "$PIPE" ]; then
    log_message "Ошибка: канал $PIPE не существует"
    exit 1
fi

if [ ! -p "$RESPONSE_PIPE" ]; then
    mkfifo "$RESPONSE_PIPE"
fi

REQUEST="${SCRIPT_NAME%.*}[$$]: how much time do I have?"
echo "$REQUEST" > "$PIPE" 2>/dev/null

if ! timeout 5 read -r N < "$RESPONSE_PIPE"; then
    log_message "Ошибка: timeout при получении ответа от cuckoo"
    exit 1
fi
 
if [[ ! $N =~ ^[0-9]+$ ]]; then
    log_message "Ошибка: получен некорректный ответ: $N"
    exit 1
fi
 
log_message "Получен ответ: работать $N секунд"

sleep "$N"
 
log_message "Скрипт завершился, работал $N секунд."
 
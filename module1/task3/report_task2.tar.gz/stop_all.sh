#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

echo "=== Остановка всех компонентов ==="

pkill -f cuckoo.sh

crontab -l 2>/dev/null | grep -v "observer.sh" | crontab -

rm -f task1.sh task2.sh task3.sh

echo "=== Готово ==="

#!/bin/bash
 
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1
 
mkdir -p /tmp/run
 
PIPE="/tmp/run/cuckoo.pid"
if [ ! -p "$PIPE" ]; then
    mkfifo "$PIPE"
fi
 
LOG_FILE="$SCRIPT_DIR/cuckoo.log"
LOCK_FILE="$SCRIPT_DIR/.cuckoo.log.lock"
 
log_message() {
    {
        flock 200
        echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
    } 200>"$LOCK_FILE"
}
 
cleanup() {
    log_message "Shutdown!"
    rm -f "$PIPE"
    exit 0
}
 
trap cleanup SIGTERM SIGINT
 
log_message "Startup!"
 
while true; do
    if read -r request < "$PIPE"; then
        if [[ $request =~ ^([^[]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            
            N=$((RANDOM % 9 + 2))
            
            RESPONSE_PIPE="/tmp/run/response_${PID}.pid"
            if [ -p "$RESPONSE_PIPE" ]; then
                echo "$N" > "$RESPONSE_PIPE" 2>/dev/null &
            fi
            
            log_message "$NAME[$PID] $N"
        fi
    fi
done
 
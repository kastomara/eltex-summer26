#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

ln -sf template_task.sh task1.sh
ln -sf template_task.sh task2.sh
ln -sf template_task.sh task3.sh

echo "Символические ссылки созданы в $SCRIPT_DIR:"
ls -la task*.sh
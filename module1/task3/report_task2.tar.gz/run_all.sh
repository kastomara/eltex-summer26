
#!/bin/bash
 
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1
 
echo "=== Запуск всех компонентов в $SCRIPT_DIR ==="
echo
 
chmod +x *.sh
 
echo "1️⃣  Запуск cuckoo.sh..."
nohup ./cuckoo.sh > /dev/null 2>&1 &
CUCKOO_PID=$!
echo "✓ cuckoo.sh запущен с PID: $CUCKOO_PID"
sleep 1
 
echo
echo "2️⃣  Создание символических ссылок..."
./links.sh
echo
 
echo "3️⃣  Проверка наличия файла конфигурации..."
if [ ! -f "observer.conf" ]; then
    echo "⚠️  observer.conf не найден! Создаю пример..."
    cat > observer.conf << 'EOF'
# Список скриптов для мониторинга
task1.sh
task2.sh
task3.sh
EOF
    echo "✓ Создан observer.conf с примером"
fi
echo
 
echo "Настройка cron..."
CRON_CMD="* * * * * cd $SCRIPT_DIR && ./observer.sh"
(crontab -l 2>/dev/null | grep -v "$SCRIPT_DIR/observer.sh"; echo "$CRON_CMD") | crontab -
if [ $? -eq 0 ]; then
    echo "Cron настроен (каждую минуту)"
else
    echo "Ошибка при настройке cron!"
fi
echo
 
echo "=== Готово ==="
echo
echo "Рабочий каталог: $SCRIPT_DIR"
echo "Логи:"
echo "   - cuckoo.log (основной сервис)"
echo "   - observer.log (мониторинг)"
echo "   - report_*.log (задачи)"
echo
echo "Для остановки выполните:"
echo "   bash $SCRIPT_DIR/stop_all.sh"
echo
echo "Для просмотра логов:"
echo "   bash $SCRIPT_DIR/check_logs.sh"
 